# PHP Compatibility Checker

A WordPress plugin to check plugins and themes for PHP version compatibility using PHP_CodeSniffer with PHPCompatibilityWP.

## Features

- **Local Scanning**: Runs entirely on your server - no external API
- **Chunked Scanning**: Handles large plugins without timeouts
- **Progress Tracking**: Visual progress bar during scans
- **Issue Details**: View detailed issue information per component
- **CSV Export**: Export results for further analysis
- **Multisite Support**: Full WordPress multisite compatibility
- **Configurable**: Custom PHPCS paths, timeouts, memory limits
- **Extensible**: Multiple hooks and filters

## Requirements

- PHP 7.2+
- WordPress 5.0+
- PHP_CodeSniffer 3.0+
- PHPCompatibilityWP

## Installation

### 1. Install PHPCS and PHPCompatibilityWP

```bash
composer global require squizlabs/php_codesniffer phpcompatibility/php-compatibility-wp
```

### 2. Install Plugin

Upload and activate through WordPress admin, or install via Composer:

```bash
composer require openclaw/php-compatibility-checker
```

### 3. Configure

Go to **PHP Compatibility > Settings** to configure:
- PHPCS path
- Scan timeout
- Chunk size
- Memory limit

## Hooks & Filters

### Filters

#### `phpcc_include_plugin`
Control which plugins are scanned.

```php
add_filter( 'phpcc_include_plugin', function( $include, $file, $data ) {
    // Exclude specific plugins
    if ( strpos( $file, 'my-plugin' ) !== false ) {
        return false;
    }
    return $include;
}, 10, 3 );
```

#### `phpcc_include_theme`
Control which themes are scanned.

```php
add_filter( 'phpcc_include_theme', function( $include, $slug, $theme ) {
    // Exclude specific themes
    if ( $slug === 'twentytwentyone' ) {
        return false;
    }
    return $include;
}, 10, 3 );
```

#### `phpcc_ignore_patterns`
Modify PHPCS ignore patterns.

```php
add_filter( 'phpcc_ignore_patterns', function( $patterns ) {
    $patterns[] = '*/custom-dir/*';
    return $patterns;
} );
```

#### `phpcc_phpcs_command`
Modify the PHPCS command before execution.

```php
add_filter( 'phpcc_phpcs_command', function( $cmd, $path ) {
    // Add custom arguments
    return $cmd . ' --report-width=200';
}, 10, 2 );
```

#### `phpcc_scan_result`
Modify scan results before caching.

```php
add_filter( 'phpcc_scan_result', function( $result, $slug ) {
    // Add custom data to results
    $result['custom_field'] = 'value';
    return $result;
}, 10, 2 );
```

### Actions

#### `phpcc_init`
Fires after plugin initialization.

```php
add_action( 'phpcc_init', function() {
    // Do something after init
} );
```

#### `phpcc_before_rescan`
Fires before a rescan is initiated.

```php
add_action( 'phpcc_before_rescan', function() {
    // Log scan start
    error_log( 'Starting compatibility scan' );
} );
```

#### `phpcc_scan_all_complete`
Fires after all items are scanned.

```php
add_action( 'phpcc_scan_all_complete', function( $results, $errors ) {
    // Send notification
    if ( ! empty( $errors ) ) {
        wp_mail( 'admin@example.com', 'Scan Errors', print_r( $errors, true ) );
    }
}, 10, 2 );
```

## Security

- All paths are validated before scanning
- Nonces verify all AJAX requests
- Capability checks on all admin pages
- Input sanitization and output escaping throughout
- PHPCS binary validation before execution

## Development

### Coding Standards

This plugin follows WordPress Coding Standards:

```bash
# Check standards
phpcs --standard=WordPress php-compatibility-checker.php

# Fix automatically
phpcbf --standard=WordPress php-compatibility-checker.php
```

### Testing

Run the scanner diagnostics:

```bash
wp phpcc diagnostics
```

## License

GPLv2 or later
